import os
from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

app = Flask(__name__)

# Configure the SQLite Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///flights.db'
db = SQLAlchemy(app)

# Define data model as a class
class Flight(db.Model):
    __tablename__ = 'flights'

    id = db.Column(db.Integer, primary_key=True)
    airport_name = db.Column(db.String)
    country_name = db.Column(db.String)
    continent = db.Column(db.String)
    departure_date = db.Column(db.String)
    arrival_airport = db.Column(db.String)
    pilot_name = db.Column(db.String)
    flight_status = db.Column(db.String)

#################################################
# Flask Routes
#################################################

# Define a route to get all flights
@app.route('/flights', methods=['GET'])
def get_all_flights():
    flights = Flight.query.all()
    flight_list = []

    for flight in flights:
        flight_data = {
            'id': flight.id,
            'airport_name': flight.airport_name,
            'country_name': flight.country_name,
            'continent': flight.continent,
            'departure_date': flight.departure_date,
            'arrival_airport': flight.arrival_airport,
            'pilot_name': flight.pilot_name,
            'flight_status': flight.flight_status
        }
        flight_list.append(flight_data)

    return jsonify(flight_list), 200

if __name__ == '__main__':
    app.run(debug=True)